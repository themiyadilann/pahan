var commands = [];

function GoldenQueen(info, func) {
    var data = info;
    data.function = func;
    if (!data.dontAddCommandList) data.dontAddCommandList = false;
    if (!info.desc) info.desc = '';
    if (!data.fromMe) data.fromMe = false;
    if (!info.category) data.category = 'misc';
    if(!info.filename) data.filename = "Not Provided";
    commands.push(data);
    return data;
}



function pushToCommands(data) {
    commands.push(data);
}

module.exports = {
    GoldenQueen,
    AddCommand:GoldenQueen,
    Function:GoldenQueen,
    Module:GoldenQueen,
    commands,
pushToCommands,
}; 
